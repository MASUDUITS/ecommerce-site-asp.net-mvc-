﻿namespace eTickets.Data
{
    public enum MovieCategory
    {
        Action =1,
        Comedy,
        Drama,
        Documentary,
            Cartoon,
            Horror
    }
}
